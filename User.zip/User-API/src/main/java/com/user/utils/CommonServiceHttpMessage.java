package com.user.utils;

public class CommonServiceHttpMessage {

    public final static String USER_CREATED = "success! USER created successfully.";
    public final static String USER_LISTED = "success! USER listed successfully.";
    
 
}
